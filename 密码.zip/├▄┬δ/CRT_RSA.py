import  math
n=3026533
for i in range(1,int(math.sqrt(n))+1):
    if n%i==0:
        p=i
        q=n//i
print(p,q)
# 扩展欧几里得求逆元
def exgcd(a, b):
    if b == 0:
        return 1, 0, a
    else:
        x, y, q = exgcd(b, a % b)
        x, y = y, (x - (a // b) * y)
        return x, y, q

# 扩展欧几里得求逆元
def ModReverse(a,p):
    x, y, q = exgcd(a,p)
    if q != 1:
        raise Exception("No solution.")
    else:
        return (x + p) % p #防止负数
    '''
def EX_GCD(a,b,arr): #扩展欧几里得
    if b == 0:
        arr[0] = 1
        arr[1] = 0
        return a
    g = EX_GCD(b, a % b, arr)
    t = arr[0]
    arr[0] = arr[1]
    arr[1] = t - int(a / b) * arr[1]
    return g
def ModReverse(a,n): #ax=1(mod n) 求a模n的乘法逆x
    arr = [0,1,]
    gcd = EX_GCD(a,n,arr)
    if gcd == 1:
        return (arr[0] % n + n) % n
    else:
        return -1
'''
def CRT(c,p,q,d,n):
    c1=c%p
    c2=c%q
    r1=d%(p-1)
    r2=d%(q-1)
    m1=pow(c1,r1)%p
    m2=pow(c2,r2)%q
    p_1=ModReverse(p,q)
    q_1=ModReverse(q,p)
    m=(m2*p*p_1+m1*q*q_1)%n
    return m
print(pow(152702,2015347,n))
m=CRT(152702,1511,2003,2015347,n)

print("RSA解密结果：",m)
