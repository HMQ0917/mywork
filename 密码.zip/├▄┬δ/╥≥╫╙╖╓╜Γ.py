import math
import gmpy2
import time
import psutil
n=2189284635403183

def findp_q(n):
    a = int(math.sqrt(n)) +1
    print(a)
    b = a * a - n
    d = math.sqrt(b)
    print("d:",d)
    m=2*a
    p=int((m+math.sqrt(m*m-4*n))/2)
    q=int((m-math.sqrt(m*m-4*n))/2)
    return p,q
print("分解n:",findp_q(n))

n1=int("246d5fd1",16)
n2=int("86a1755c41 ",16)
n3=int("2fbf76ea9f0b3 ",16)
def fenjie(n):
    a=2
    if(gmpy2.is_prime(n)==1):
        print(hex(n))
        return
    else:
        for i in range(1,n-1):
            a=pow(a,i,n)
            d=gmpy2.gcd(a-1,n)
            if d==1:
                continue
            if d==n:
                a+=1
            else:
                print(d)
                fenjie(d)
                fenjie(n//d)

                return


t=time.time()
print("分解n1")
fenjie(n1)
print("cpu使用率",psutil.cpu_percent())
t0=time.time()
print(t0-t,"s")
'''
t1=time.time()
print("分解n2")
fenjie(n2)
print("cpu使用率",psutil.cpu_percent())
t2=time.time()
print(t2-t1,"s")
t3=time.time()
print("分解n3")
fenjie(n3)
print("cpu使用率",psutil.cpu_percent())
t4=time.time()
print(t4-t3,"s")'''