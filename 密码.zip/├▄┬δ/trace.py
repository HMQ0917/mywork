
path_r = r"d:\Users\lenovo\Desktop\memoryaccess.txt"
with open(path_r, "r") as f:  # 打开文件
    data = f.readlines()  # 读取文件
    d=data[61870:]
path_w = r"d:\Users\lenovo\Desktop\b.txt"
with open(path_w, "w") as f:    # 以写的方式打开结果文件
   for line in d:
        f.write(line)  # 把数值写入文件，自带文件关闭功能，不需要再写f.close()



path_r = r"d:\Users\lenovo\Desktop\b.txt"
with open(path_r, "r") as f:  # 打开文件
    data = f.read()  # 读取文件
path_w = r"d:\Users\lenovo\Desktop\trace.txt"
with open(path_w, "w") as f:    # 以写的方式打开结果文件
    i = -1  # 用来记录本次循环数据所在位置
    j = data.rfind('address')   # 找到最后一条数据所在的位置
    while i < j:
        start = i+1  # 每次查找都要从上一条数据之后的位置开始，默认从0开始
        i = data.index('address', start)    # 从start开始查找，返回now第一次出现的位置
        result = data[i+7:i+15]     # i+7是从address的位置往后移，i+14是指数值部分只取7位
        f.write(result)  # 把数值写入文件，自带文件关闭功能，不需要再写f.close()
        f.write('\n')   # 换行




