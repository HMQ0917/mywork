# 26个字母的频率
P = [
    0.08167, 0.01492, 0.02782,
    0.04253, 0.12702, 0.02228,
    0.02015, 0.06094, 0.06966,
    0.00153, 0.00772, 0.04025,
    0.02406, 0.06749, 0.07507,
    0.01929, 0.00095, 0.05987,
    0.06327, 0.09056, 0.02758,
    0.00978, 0.02360, 0.00150,
    0.01974, 0.00074
]


def count_IC(cipher):  # 计算重合指数IC
    n = len(cipher)
    f = 26 * [0]
    for i in range(n):
        f[ord(cipher[i]) - ord('a')] += 1  # 密文中每个字母出现的频数
    IC = 0
    for i in range(26):
        IC += (f[i] * (f[i] - 1)) / (n * (n - 1))
    return IC


# 秘钥长度为key_len时的IC
def key_IC(cipher, key_len):
    IC = 0
    f = key_len * ['']
    for i in range(len(cipher)):
        z = i % key_len
        f[z] += cipher[i]  # 分为key_len个部分，分别计算重合指数
    for i in range(key_len):
        f[i] = count_IC(f[i])
        IC += f[i]
    IC = IC / key_len  # 取平均值，如果猜测正确，值应接近0.065
    return IC


# 第一步，猜测秘钥长度
def length(cipher):
    ic = [(1, abs(0.065 - count_IC(cipher)))] + 29 * [(0, 0)]  # 密钥长度为1时为整个密文的重合指数
    for i in range(2, 31):  # 猜测密钥长度为2~30
        ic[i - 1] = (i, abs(0.065 - key_IC(cipher, i)))  # 与0.065相差值
    ic = sorted(ic, key=lambda x: x[1])  # 按相差值排序
    for i in range(5):  # 前五个最可能长度
        print(ic[i])


with open("1.txt", "r") as f:
    cipher = f.read()  # 密文
print("秘钥可能长度:")
length(cipher)


# 计算猜测密钥的重合指数，确定偏移量
def count_IC2(cipher, s):  # s为偏移量
    f = 26 * [0]
    n = len(cipher)
    for i in range(n):
        f[(ord(cipher[i]) - ord('a')) % 26 - s] += 1  # 计算猜测的明文中所有字母的频数
    IC2 = 0
    for i in range(26):
        IC2 += ((f[i] / n) * P[i])  # 若偏移量正确，IC2接近0.065
    return IC2


# 第二步，猜测每组的偏移量，即字母
def offset(cipher):
    ic = 26 * [(0, 0)]
    for i in range(26):
        ic[i] = (chr(ord('a') + i), abs(0.065 - count_IC2(cipher, i)))  # (猜测偏移量a-z,与0,065差值)
    ic = sorted(ic, key=lambda x: x[1])
    return ic[0][0]  # 最可能的字母


def key(cipher, key_len):  # 确定密钥
    f = key_len * ['']
    key = ''
    for i in range(len(cipher)):  # 将密文分为key_len个组
        z = i % key_len
        f[z] += cipher[i]
    for i in range(key_len):
        key += offset(f[i])  # 取每组最可能的字母作密钥
    print("key:", key)
    return key


# 第三步，解密
def decryption(cipher, key_len, s):
    plain = ''
    i = 0
    while (i < len(cipher)):
        for j in range(key_len):
            plain += chr((ord(cipher[i]) - ord(s[j])) % 26 + ord('a'))
            i += 1
            if (i == len(cipher)):
                break
    f = open("明文2.txt", "w")  # 写入文件
    f.write(plain)
    f.close()


key_len = int(input("猜测密钥长度："))  # 秘钥长度
key = key(cipher, key_len)
decryption(cipher, key_len, key)








