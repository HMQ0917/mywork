#21264a40d8845dff602e2c2f9c006e68fa3a9324eb0f50a6fc564d99ebe07793ddee19ed96900c3dc5491e737504dc1033adf290f38fa0f5df5e4a4fca1a50d2
import subprocess
import time
iv_c='21264a40d8845dff602e2c2f9c006e68fa3a9324eb0f50a6fc564d99ebe07793ddee19ed96900c3dc5491e737504dc1033adf290f38fa0f5df5e4a4fca1a50d2'
IV=iv_c[:32]
C=iv_c[32:]
clist=[]#密文列表
Mlis = []#明文列表
midlis = []#中间值列表
#密文分组
for i in range(0,len(C),32):
    clist.append(C[i:i+32])
ivlis = [IV, clist[0], clist[1]]
#差分(一个字节）
def diff(a,b):
    c=hex(int(a,16)^int(b,16))[2:].zfill(2)
    return c
#攻击
def p_o (clist,iv):
    for i in range(len(clist)):
        iv='00000000000000000000000000000000'
        mid=[]
        ci=clist[i]
        ivv=""
        for j in range(1,17):
            for k in range(256):
                t=hex(k)[2:].zfill(2)
                iv1=iv[:32-j*2]+t+ivv#从最后一个字节开始破解
                #print(len(iv1))
                iv1_ci=iv1+ci
                a = subprocess.call(['dec_oracle',iv1_ci])
                if(a==200):
                    print("find")
                    mid.append(diff(t,hex(j)[2:]))#从最后一个字节开始存储中间值
                    mm=mid[::-1]
                    tt=[]
                    for mi in mm:
                        tt.append(diff(mi,hex(j+1)[2:]))
                    ivv="".join(tt)#破解下一个字节时，该字节后的iv值
                    break
        midi="".join(mid[::-1])#逆序拼接
        print("*************第",i,"组 is OK *************")
        midlis.append(midi)#中间值列表
    ivlis = [IV, clist[0], clist[1]]
    for h in range(3):
        b = hex(int(midlis[h], 16) ^ int(ivlis[h], 16))[2:]
        Mlis.append(b)
t1=time.time()
p_o(clist,IV)
#print("************OK*********")
print("明文：")
print(Mlis)
t2=time.time()
print("时间：",t2-t1)
print("中间值：")
print(midlis)




