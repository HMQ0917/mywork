from gmpy2 import*

def getg(n):#原根
    for i in range(2,n-1):
        if pow(i,(n-1)//2,n)!=1:
            return i
#print(getg(41))

def fenjie(n):#分解质因子n-1
    a={}
    m=n
    for i in range(2,m):
        if n%i==0:
            a[i]=1
            n = n // i
            while(n%i==0):
                a[i]+=1
                n=n//i
    return a
#yz=fenjie(40)
#print(yz)
def CRT(a,m):#孙子定理
    M=1
    for mi in m:
        M*=mi
    Milis=[]
    Mini = []
    for mi in m:
        Milis.append(M//mi)
        Mini.append(invert(M//mi,mi))
    x=0
    for i in range(len(a)):
        x+=Milis[i]*Mini[i]*a[i]
        x%=M
    return x




def p_h(a,b,p):
    yzdic=fenjie(p-1)
    n=len(yzdic)
    yzlis=list(yzdic.keys())#质因数列表
    yznum=list(yzdic.values())#相应质因数次数
    mlis=[]
    xlis=[]
    for i in range(n):#n个质因子循环n次得到n个同余方程
        yz=yzlis[i]
        cs=yznum[i]
        #课本算法
        blis = [0]*cs#bj列表
        blis[0]=b
        arr =[0]*cs#xi表达式系数列表
        j=0
        while j<=cs-1:#循环求解系数
            d=pow(yz,j+1)
            c=pow(blis[j],(p-1)//d,p)

            for m in range(1,yz):
                #print(pow(a,m*(p-1)//yz,p),c)
                if pow(a,m*(p-1)//yz,p)==c:
                    #print(m)
                    arr[j]=m
            if j<cs-1:
                blis[j+1]=blis[j]*invert(pow(a,arr[j]*pow(yz,j)),p)%p
                print(arr[j])
                print(invert(pow(a,arr[j]*pow(yz,j)),p))


            j+=1

        xi=0
        for i in range(len(arr)):#求得xi
            xi+=arr[i]*pow(yz,i)
        mlis.append(pow(yz,cs))#模数列表
        xlis.append(xi)#xi列表
    print(xlis,mlis)
    print("离散对数为：",CRT(xlis, mlis))#CRT解同余方程

p_h(6,29,41)
p_h(2,29,37)
#print(pow(6,7,41))
#print(pow(2,21,37))



















