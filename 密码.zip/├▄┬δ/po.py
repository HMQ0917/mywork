import subprocess
def get_hex_2(x):
    #return str(hex(x))[2:]
    if (len(str(hex(x)).replace("0x", '')) == 1):
        return('0'+str(hex(x)).replace("0x", ''))
    else:
        return(str(hex(x)).replace("0x", ''))
def get_aj_1(j,r,c3,a):
    y=''
    for k in range(j):
        t=(j+1)^int(a[len(a)-2*j+2*k:len(a)-2*j+2*k+2],16)
        y=y+get_hex_2(t)
    for i in range(0x00,0x100):
        x=get_hex_2(i)
        rr=r[0:32-2*(j+1)]+x+y
        if(subprocess.call(['dec_oracle',rr+c3])==200):
            return i
def get_m(c2,c3):
    m3 = ''
    r_pre = '000000000000000000000000000000'
    a = ''
    for i in range(0x00, 0xFF):
        temp_r = r_pre + get_hex_2(i)
        temp = temp_r + c3
        if (subprocess.call(['dec_oracle', temp]) == 200):
            r = temp_r
            break
    for i in range(16):
        temp_r = r[0:2 * i] + '01' + r[2 * i + 2:]
        temp = temp_r + c3
        if (subprocess.call(['dec_oracle', temp]) == 500):
            l = 16 - i
            for j in range(l):
                lll = l ^ int(r[32 - 2 * l + 2 * j:32 - 2 * l + 2 * j + 2], 16)
                a = a + get_hex_2(lll)
            break
    print("__--------",l,"---------")
    for i in range(l, 16):
        x = get_aj_1(i, r, c3, a)
        print(x)
        a = get_hex_2(x ^ (i + 1)) + a
    for i in range(16):
        m3 = m3 + get_hex_2(int(c2[2 * i:2 * i + 2], 16) ^ int(a[2 * i:2 * i + 2], 16))
    return m3

iv='21264a40d8845dff602e2c2f9c006e68'
c1='fa3a9324eb0f50a6fc564d99ebe07793'
c2='ddee19ed96900c3dc5491e737504dc10'
c3='33adf290f38fa0f5df5e4a4fca1a50d2'

m2=get_m(c1,c2)
print('m2=',m2)

#m3=get_m(c2,c3)
#print('m3=',m3)
#m1=get_m(iv,c1)
#print('m1=',m1)

