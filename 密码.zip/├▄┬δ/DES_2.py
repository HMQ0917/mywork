import DES
import time
c1="3637232aaab78692"
c2="70de8bbfe1892b7c"
p1="0"
p2="1"
P1=DES.pre_do(p1)
P2=DES.pre_do(p2)
C1=DES.pre_do(c1)
C2=DES.pre_do(c2)
keyrear="1235789abd"
keyRear=bin(int(keyrear,16))[2:].zfill(40)
def getkeylist():#建立key列表2**24
    keylist=[]
    for i in range(2**24):
        keyhead=bin(i)[2:].zfill(24)
        key=keyhead+keyRear
        keylist.append(key)

    return keylist
def table_l(P,keylist):#在每一个key0下对明文加密
    tab=[]
    for ki in keylist:
        tab.append(DES.DES(P,ki,0))

        print("running1")
    print("table is ready")
    #print(tab)
    return tab



def Midmeet(tab,C,keylist):#中间相遇攻击
    xlist=[]

    for ki in keylist:#在每个可能的key1下对密文解密
        x=DES.DES(C,ki,1) #flag 为1，表示解密
        xlist.append(x)
        print("running2")
    #print(xlist)
    print("xlist is ready")
    set1=set(tab)
    set2=set(xlist)
    iset=set1.intersection(set2)
    print("相遇",iset)
    for xi in iset:
        keylist0 = []
        keylist1=[]
        k1 = [i for i, x in enumerate(xlist) if x ==xi]
        k0=[i for i, x in enumerate(tab) if x ==xi]
        for ki in k0:
            K = bin(ki)[2:].zfill(24) + keyRear
            keylist0.append(K)
        for ki in k1:
            K = bin(ki)[2:].zfill(24) + keyRear
            keylist1.append(K)
        print("对于中间值",xi,"破解出的密钥：")
        print("k0",keylist0)
        print("k1",keylist1)

    print("ok")

t1=time.time()
keylist=getkeylist()

#tab=table_l(P1,keylist)
#Midmeet(tab,C1,keylist)
tab1=table_l(P2,keylist)
Midmeet(tab1,C2,keylist)
t2=time.time()
print("中间相遇攻击用时：",t2-t1,"s")

