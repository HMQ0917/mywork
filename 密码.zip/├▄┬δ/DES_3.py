from DES import *

#两个明密文对
p_c=[[pre_do("80CB4F7C993B1782"),pre_do("EBEB4AF9993B1782"),pre_do("746A0EFD1EE535D4"),pre_do("626106E0607EC3BD")],
     [pre_do("54A281EFDCD118C9"),pre_do("2812AC18DCD118C9"),pre_do("B29D363555820170"),pre_do("6D0DC7CE3844BE01")]]
#print(p_c)

#P逆置换
P_1=[]
for i in range(32):
    P_1.append(P.index(i+1)+1)
#print(P_1)

#差分
def differ(s1,s2):
    dif=bin(int(s1, 2) ^ int(s2, 2))[2:]
    return dif

#计算alpha
def find_alpha(r3,R3,l0,L0):
    a=differ(differ(r3,R3).zfill(32),differ(l0,L0).zfill(32)).zfill(32)
    return a

#P逆（alpha)
def p_1_alpha(a):
    b=""
    for i in P_1:
        b+=a[i-1]
    return b

#进入第n个s盒
def s_box(a,n):
    col = int(a[1:5], 2)
    row = int(a[0] + a[5], 2)
    s_a = bin(S[n][row][col])[2:].zfill(4)
    return s_a

def differ_attack(p_c):
    key3list=[]

    for n in range(8):
        Count = [0] * 64  # 计数器
        for i in range(2):
            l0=p_c[i][0][0:32]
            L0=p_c[i][1][0:32]
            l3=p_c[i][2][0:32]
            L3=p_c[i][3][0:32]
            r3=p_c[i][2][32:64]
            R3=p_c[i][3][32:64]
            E_l3=Ek(l3)
            E_L3 = Ek(L3)

            a=find_alpha(r3, R3, l0, L0)

            b= p_1_alpha(a)


            b_4=[b[j:j+4] for j in range(0,32,4)] # P逆（alpha)分成八组

            E_l3_8 = [E_l3[j:j+6] for j in range(0,48,6)] #E(l3)分成八组
            E_L3_8 = [E_L3[j:j + 6] for j in range(0, 48, 6)]#E(L3)分成八组


            for m in range(64): #遍历每组6比特的密钥k_6
                k_6=bin(m)[2:].zfill(6)
                k_El3=bin(int(k_6,2)^int(E_l3_8[n],2))[2:].zfill(6)#k_6 与E(l3)异或
                k_EL3=bin(int(k_6,2)^int(E_L3_8[n],2))[2:].zfill(6)#k_6 与E(L3)异或
                s1=s_box(k_El3,n)#异或后进入S盒
                s2=s_box(k_EL3,n)
                dif=differ(s1,s2).zfill(4)#S盒输出的异或
                if dif==b_4[n]:
                    Count[m]+=1#相应计数器加一



        k_max=[i for i ,x in enumerate(Count) if x==max(Count)]#count值最大的k_6
        key3list.append(k_max)
    #print(key3list)
        #转化为二进制形式
    for i in range(8):
        for j in range(countlist(key3list[i])):
            key3list[i][j]=bin(key3list[i][j])[2:].zfill(6)


    return key3list

def countlist(lis):#统计列表中元素个数
    num=0
    for i in lis:
        num+=1
    return num

#回溯法输出所有可能的key3
key=[]
key3set=[]
def search(i,key3list):
    if i==8:
        key3set.append("".join(key))
        return
    for j in range(countlist(key3list[i])):
        key.append(key3list[i][j])
        search(i+1,key3list)
        key.pop()





key3list=differ_attack(p_c)
print("差分攻击得到key3分组列表:",key3list)
search(0,key3list)
print("key3集合：",set(key3set))
print("key3集合中元素个数：",countlist(key3set))


















