import DES
import time
p1="0000000000000000"
c1="d76346397c9fb03b"
p2="0000000000000001"
c2="d2e7f4569792b897"
P1=DES.pre_do(p1)
P2=DES.pre_do(p2)
C1=DES.pre_do(c1)
C2=DES.pre_do(c2)
keyrear="1235789abd"
keyRear=bin(int(keyrear,16))[2:].zfill(40)

def findall(P,C):
    Key=[]
    for i in range(2**24):
        keyhead=bin(i)[2:].zfill(24)
        key=keyhead+keyRear
        if DES.DES(P,key,0)==C:
            Key.append(key)
        print("running")
    print("ok")
    return Key

def gettable(P):#预计算
    clist=[]
    for i in range(2 ** 24):
        keyhead = bin(i)[2:].zfill(24)
        key = keyhead + keyRear
        clist.append(DES.DES(P,key,0))
        print("table is doing")
    print("table is ready")
    return clist
def findtable(tab,C):#查表
    keylist=[]
    k1 = [i for i, x in enumerate(tab) if x ==C]
    for ki in k1:
        K=bin(ki)[2:].zfill(24)+keyRear
        keylist.append(K)
    return keylist

t1=time.time()
Key1=findall(P1,C1)
print("密钥：",Key1)
#Key2=findall(P2,C2)
#print("第二对密钥",Key2)
t2=time.time()
print("穷举用时：",t2-t1)

'''
t3=time.time()
tab=gettable(P1)
keylist=findtable(tab,C1)
print(keylist)
#tab1=gettable(P2)
#keylist1=findtable(tab1,C2)
#print(keylist1)
t4=time.time()
print("查表攻击用时：",t4-t3)

'''

